import React from 'react'

const RepresentativeBoard = () => {
  return (
    <div>HiBoard</div>
  )
}

export default RepresentativeBoard