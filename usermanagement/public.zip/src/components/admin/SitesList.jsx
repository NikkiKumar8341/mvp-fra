import React from 'react'

const SitesList = () => {
  return (
    <div>SitesList</div>
  )
}

export default SitesList