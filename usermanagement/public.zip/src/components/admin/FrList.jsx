import React from 'react'

const FrList = () => {
  return (
    <div>FrList</div>
  )
}

export default FrList